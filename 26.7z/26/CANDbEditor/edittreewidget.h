#ifndef EDITTREEWIDGET_H
#define EDITTREEWIDGET_H

#include <QTreeWidget>

class editTreeWidget : public QTreeWidget
{
    Q_OBJECT
public:
    explicit editTreeWidget(QWidget *parent = 0);
    void setModel(QAbstractItemModel * model){
        QTreeView::setModel(model);
    }

signals:

public slots:

};

#endif // EDITTREEWIDGET_H
